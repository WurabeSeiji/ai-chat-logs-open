#!/usr/bin/env python3
"""Partial zero-closure analysis for N=3..16 final edge data.
For each vertex v of K_N, test the (N-1)-edge star E_v:
 C(E_v)=|sum z_e^2| / sum |z_e^2|.
The complement is tested as well. This is the structural k>=4 family revealed
by extending the previous 2/3-edge search.
"""
from pathlib import Path
import pandas as pd, numpy as np
ROOT=Path(__file__).resolve().parent
TOL=1e-6
rows=[]
blocks=[]
for N in range(3,17):
    d=pd.read_csv(ROOT/f"SOURCE_N{N}_step5000_final_edges.csv")
    z=d.z2_re.to_numpy()+1j*d.z2_im.to_numpy()
    rs=[]; rc=[]
    for v in range(1,N+1):
        mask=(d.i.to_numpy()==v)|(d.j.to_numpy()==v)
        r=abs(z[mask].sum())/np.abs(z[mask]).sum()
        cm=~mask
        cr=abs(z[cm].sum())/np.abs(z[cm]).sum() if cm.any() else np.nan
        rs.append(r); rc.append(cr)
        blocks.append([N,v,int(mask.sum()),r,
            ",".join(f"{int(i)}-{int(j)}" for i,j in zip(d.i[mask],d.j[mask]))])
    rows.append([N,len(d),N-1,min(rs),max(rs),sum(x<TOL for x in rs),
                 np.nanmin(rc),np.nanmax(rc)])
pd.DataFrame(rows,columns=["N","M","star_size_Nminus1","min_star_residual",
"max_star_residual","zero_stars_lt1e-6","min_complement_residual",
"max_complement_residual"]).to_csv(ROOT/"reproduced_vertex_star_closures.csv",index=False)
pd.DataFrame(blocks,columns=["N","vertex","k","residual","edges"]).to_csv(
ROOT/"reproduced_vertex_star_blocks.csv",index=False)
