N=3..16 k>=4 partial zero-closure analysis.
Contains source final-edge data, vertex-star and complement residuals, time evolution,
figures, reproducible analysis code, and ANALYSIS.md.
Threshold C<1e-6. No physics was rerun or modified; analysis uses the saved step-5000 data.
