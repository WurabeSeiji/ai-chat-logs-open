
from pathlib import Path
import importlib.util, numpy as np, pandas as pd, math, json, hashlib, zipfile, shutil
from fractions import Fraction
import matplotlib.pyplot as plt

base=Path("/mnt/data")
engine_path=base/"run_n_scaling_lowrank_v1.py"
OUT=base/"N5_make_parent_phase_path_test"
OUT.mkdir(exist_ok=True)

spec=importlib.util.spec_from_file_location("eng",engine_path)
eng=importlib.util.module_from_spec(spec); spec.loader.exec_module(eng)

N=5; SEED=40260722+1000*N; ITERS=1200; BETA=0.5; TOL=1e-12; RESTARTS=3; MAX_DEN=64
def wrap_pi(x): return ((x+np.pi/2)%np.pi)-np.pi/2

def phase_metrics(theta):
    M=len(theta)
    D=wrap_pi(theta[:,None]-theta[None,:])
    vals=D[np.triu_indices(M,1)]/np.pi
    errs=[]; dens=[]
    for x in vals:
        fr=Fraction(float(x)).limit_denominator(MAX_DEN)
        errs.append(abs(float(x)-float(fr))); dens.append(fr.denominator)
    errs=np.asarray(errs,float)
    global_q=None; best_any=float("inf")
    for q in range(1,MAX_DEN+1):
        me=float(np.max(np.abs(vals-np.round(vals*q)/q))) if len(vals) else 0.0
        best_any=min(best_any,me)
        if global_q is None and me<1e-10: global_q=q
    rel=np.mod(theta-theta[0],np.pi); rels=np.sort(rel)
    clusters=[]
    for val in rels:
        if not clusters or abs(val-np.mean(clusters[-1]))>1e-10: clusters.append([float(val)])
        else: clusters[-1].append(float(val))
    return dict(pair_count=len(vals), max_rat_err_q_le_64=float(errs.max()), median_rat_err_q_le_64=float(np.median(errs)),
                frac_err_lt_1e10=float(np.mean(errs<1e-10)), unique_best_denominators=";".join(map(str,sorted(set(dens)))),
                smallest_global_q_tol_1e10=global_q, best_global_maxerr_any_q_le_64=best_any,
                phase_class_count_tol_1e10=len(clusters))

def instrumented_make_parent(sys_lr,rng,iters=ITERS,beta=BETA,tol=TOL,restarts=RESTARTS):
    best=(None,np.inf,None); trace=[]; restarts_out=[]
    for restart in range(restarts):
        theta=rng.uniform(0,2*np.pi,sys_lr.m); v=None
        rec=dict(restart=restart,iter=0,stage="theta_input_initial",residual=np.nan,**phase_metrics(theta))
        rec.update({f"theta_{m}":float(theta[m]) for m in range(sys_lr.m)}); trace.append(rec)
        for it in range(iters):
            theta_in=theta.copy(); sys_lr.set_theta(theta_in)
            ev,EV=np.linalg.eig(sys_lr.J@sys_lr.G); idx=int(np.argmin(ev.imag))
            v=sys_lr.w(EV[:,idx].astype(complex)); v=v/np.linalg.norm(v)
            theta_new=np.angle(v)
            mix=(1-beta)*np.exp(1j*theta_in)+beta*np.exp(1j*theta_new)
            theta_next=np.angle(mix)
            sys_lr.set_theta(theta_new)
            res_now=eng._eigenmode_residual(sys_lr,v)
            for stage,th in (("theta_in",theta_in),("theta_new_from_v",theta_new),("theta_next_mixed",theta_next)):
                rec=dict(restart=restart,iter=it+1,stage=stage,residual=float(res_now),**phase_metrics(th))
                rec.update({f"theta_{m}":float(th[m]) for m in range(sys_lr.m)}); trace.append(rec)
            theta=theta_next
            if it%10==9 and res_now<tol: break
        sys_lr.set_theta(np.angle(v)); residual=eng._eigenmode_residual(sys_lr,v)
        restarts_out.append({"restart":restart,"iterations":it+1,"residual":float(residual)})
        if residual<best[1]: best=(v.copy(),float(residual),sys_lr.sigma_spectrum().copy())
        if residual<tol: break
    v,residual,sig=best; sys_lr.set_theta(np.angle(v))
    return v,residual,sig,pd.DataFrame(trace),restarts_out

sys_i=eng.LowRankSystem(N); rng_i=np.random.default_rng(SEED)
v_i,res_i,sig_i,trace_df,restart_summaries=instrumented_make_parent(sys_i,rng_i)

sys_o=eng.LowRankSystem(N); rng_o=np.random.default_rng(SEED)
v_o,res_o,sig_o=eng.make_parent(sys_o,rng_o,iters=ITERS,beta=BETA,tol=TOL,restarts=RESTARTS)

phase=np.angle(np.vdot(v_o,v_i)); v_i_aligned=v_i*np.exp(-1j*phase)
max_v_diff=float(np.max(np.abs(v_i_aligned-v_o)))
res_diff=float(abs(res_i-res_o)); sig_diff=float(np.max(np.abs(np.asarray(sig_i)-np.asarray(sig_o))))

trace_df.to_csv(OUT/"N5_make_parent_phase_trace.csv",index=False)

M=N*(N-1)//2; pair_rows=[]
for _,r in trace_df[trace_df.stage=="theta_next_mixed"].iterrows():
    th=np.array([r[f"theta_{m}"] for m in range(M)],float)
    D=wrap_pi(th[:,None]-th[None,:])/np.pi
    for i in range(M):
        for j in range(i+1,M):
            x=float(D[i,j]); fr=Fraction(x).limit_denominator(MAX_DEN)
            pair_rows.append([int(r.restart),int(r.iter),i,j,x,fr.numerator,fr.denominator,abs(x-float(fr))])
pd.DataFrame(pair_rows,columns=["restart","iter","edge_i","edge_j","delta_theta_over_pi_mod_pi","best_p","best_q_le_64","abs_error"]).to_csv(OUT/"N5_pairwise_phase_differences_by_iteration.csv",index=False)

summary_df=trace_df[trace_df.stage=="theta_next_mixed"][["restart","iter","residual","max_rat_err_q_le_64","median_rat_err_q_le_64","frac_err_lt_1e10","smallest_global_q_tol_1e10","best_global_maxerr_any_q_le_64","phase_class_count_tol_1e10"]].copy()
summary_df.to_csv(OUT/"N5_phase_discretization_iteration_summary.csv",index=False)

theta_final=np.angle(v_o); rel_final=wrap_pi(theta_final-theta_final[0])/np.pi
final_rows=[]
for i,x in enumerate(rel_final):
    fr=Fraction(float(x)).limit_denominator(MAX_DEN)
    final_rows.append([i,float(x),fr.numerator,fr.denominator,abs(float(x)-float(fr))])
pd.DataFrame(final_rows,columns=["edge_index","phase_rel_over_pi","p","q","abs_error"]).to_csv(OUT/"N5_final_parent_relative_phases.csv",index=False)

plt.figure(figsize=(8,5)); plt.semilogy(summary_df["iter"],np.maximum(summary_df["max_rat_err_q_le_64"],1e-18)); plt.xlabel("make_parent iteration"); plt.ylabel("max rational-lock error (q <= 64)"); plt.title("N=5: convergence toward discrete relative-phase classes"); plt.tight_layout(); plt.savefig(OUT/"N5_rational_lock_error.png",dpi=180); plt.close()
plt.figure(figsize=(8,5)); plt.semilogy(summary_df["iter"],np.maximum(summary_df["residual"],1e-18)); plt.xlabel("make_parent iteration"); plt.ylabel("self-consistency residual"); plt.title("N=5: make_parent fixed-point residual"); plt.tight_layout(); plt.savefig(OUT/"N5_self_consistency_residual.png",dpi=180); plt.close()
plt.figure(figsize=(8,5)); plt.plot(summary_df["iter"],summary_df["phase_class_count_tol_1e10"]); plt.xlabel("make_parent iteration"); plt.ylabel("phase class count (mod pi, tol 1e-10)"); plt.title("N=5: relative phase-class count during make_parent"); plt.tight_layout(); plt.savefig(OUT/"N5_phase_class_count.png",dpi=180); plt.close()

next_rows=trace_df[trace_df.stage=="theta_next_mixed"].sort_values("iter"); mat=[]; iters=[]
for _,r in next_rows.iterrows():
    th=np.array([r[f"theta_{m}"] for m in range(M)],float); mat.append(wrap_pi(th-th[0])/np.pi); iters.append(int(r.iter))
mat=np.asarray(mat)
plt.figure(figsize=(9,5)); plt.imshow(mat.T,aspect="auto",origin="lower",extent=[iters[0],iters[-1],0,M-1]); plt.xlabel("make_parent iteration"); plt.ylabel("edge index"); plt.title("N=5: relative phases / pi (mod pi)"); plt.colorbar(label="relative phase / pi"); plt.tight_layout(); plt.savefig(OUT/"N5_relative_phase_heatmap.png",dpi=180); plt.close()

locked=summary_df[summary_df["smallest_global_q_tol_1e10"].notna()]
first_lock=int(locked.iloc[0]["iter"]) if len(locked) else None
final_metrics=phase_metrics(theta_final)
summary={"N":N,"M":M,"seed":SEED,"iters_requested":ITERS,"beta":BETA,"tol":TOL,"restarts":RESTARTS,
         "original_vs_instrumented":{"max_abs_v_diff_after_global_phase_alignment":max_v_diff,"residual_diff":res_diff,"sigma_spectrum_max_abs_diff":sig_diff,"original_residual":float(res_o),"instrumented_residual":float(res_i)},
         "restart_summaries":restart_summaries,"first_iteration_with_global_rational_lock_tol_1e10":first_lock,
         "final_phase_metrics":final_metrics,"final_relative_phases":final_rows}
(OUT/"N5_make_parent_phase_analysis_summary.json").write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding="utf-8")

# inspect when global q appears and representative iterations
rep_iters=sorted(set([1,2,3,5,10,20,40,80,120,160] + ([first_lock] if first_lock else [])))
rep=summary_df[summary_df["iter"].isin(rep_iters)]
rep.to_csv(OUT/"N5_representative_iteration_metrics.csv",index=False)

analysis=f"""# N=5 make_parent 位相離散化経路の直接検証

## 実験条件
N={N}, M={M}, seed={SEED}, beta={BETA}, tol={TOL}, iters={ITERS}, restarts={RESTARTS}。
元の `make_parent` の計算式は変更していない。追加したのは各反復の位相と診断量の保存のみ。

## 非侵襲性の確認
元 `make_parent` と計測版を同一seed・同一条件で別々に実行し、最終固有ベクトルを全体位相だけ合わせて比較した。

- max |Δv| = {max_v_diff:.3e}
- residual差 = {res_diff:.3e}
- σスペクトル最大差 = {sig_diff:.3e}

したがって解析追加による最終解の変化は検出されなかった。

## 測定
各反復の `theta_next_mixed` について、全45組の相対位相差 Δθ/π (mod π) を保存した。
さらに各stepで、
- 分母64以下の最良有理数近似誤差
- 全45組を一つの共通分母qで同時表現できる最小q（tol=1e-10）
- mod π の位相クラス数
- 自己無撞着残差
を記録した。

## 結果
最終親状態:
- 最小共通分母 q = {final_metrics['smallest_global_q_tol_1e10']}
- 最良近似分母集合 = {final_metrics['unique_best_denominators']}
- 最大有理ロック誤差 = {final_metrics['max_rat_err_q_le_64']:.3e}
- 位相クラス数 = {final_metrics['phase_class_count_tol_1e10']}

全45組が tol=1e-10 で有限共通分母に初めてロックした反復:
- iteration = {first_lock}

途中の各stepが連続値を通るのか、有限位相パターン間だけを移るのかは `N5_phase_discretization_iteration_summary.csv` と `N5_relative_phase_heatmap.png` に全反復を保存した。
"""
(OUT/"ANALYSIS.md").write_text(analysis,encoding="utf-8")

shutil.copy2(engine_path,OUT/"run_n_scaling_lowrank_v1_ORIGINAL.py")
# save this exact instrumentation source
shutil.copy2(Path(__file__) if "__file__" in globals() else engine_path, OUT/"_runtime_source_placeholder.py")
# will be replaced outside by caller with this file itself if desired

checks=[]
for p in sorted(OUT.iterdir()):
    if p.is_file():
        checks.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}")
(OUT/"SHA256SUMS.txt").write_text("\n".join(checks)+"\n",encoding="utf-8")

print(json.dumps(summary,indent=2,ensure_ascii=False))
print("\nRepresentative iteration metrics:\n",rep.to_string(index=False))
