#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd

SNAP_STEPS=[0,50,100,150,200,250,300,350,400,450,500,750,1000,1500,2000,2500,3000,3500,4000,4500,5000]
TOLS=[1e-2,1e-3,1e-4,1e-6,1e-8]

def cluster_count(vals,tol):
    centers=[]; counts=[]
    for vv in vals:
        hit=None
        for ci,c in enumerate(centers):
            if np.max(np.abs(vv-c))<tol: hit=ci; break
        if hit is None: centers.append(vv.copy()); counts.append(1)
        else: counts[hit]+=1
    return len(centers), sorted(counts,reverse=True)

def forever_step(steps,values,thr):
    suffix=np.maximum.accumulate(values[::-1])[::-1]
    ix=np.flatnonzero(suffix<thr)
    return int(steps[ix[0]]) if len(ix) else None

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir',type=Path,default=Path('.'))
    ap.add_argument('--output-dir',type=Path,default=Path('.'))
    a=ap.parse_args(); inp=a.input_dir; out=a.output_dir; out.mkdir(parents=True,exist_ok=True)
    ph=pd.read_csv(inp/'N16_selected_snapshots_long.csv')
    gl=pd.read_csv(inp/'N16_global_summary.csv')
    fin=ph[ph.step==5000].copy().sort_values('edge_index')
    for col,val in [('a2n',fin.a2/fin.r2),('b2n',fin.b2/fin.r2),('abn',fin.ab/fin.r2),('z2n_re',fin.z2_re/fin.r2),('z2n_im',fin.z2_im/fin.r2)]: fin[col]=val
    fin.to_csv(out/'N16_step5000_final_edges_with_normalized_components.csv',index=False)

    rows=[]
    for t in SNAP_STEPS:
        g=ph[ph.step==t].sort_values('edge_index')
        vals=np.c_[g.a2/g.r2,g.b2/g.r2,g.ab/g.r2]
        for tol in TOLS:
            n,sizes=cluster_count(vals,tol); rows.append([t,tol,n,';'.join(map(str,sizes))])
    pd.DataFrame([[x[0],x[1],x[2]] for x in rows],columns=['step','tol','triplet_cluster_count']).to_csv(out/'N16_triplet_cluster_counts_selected_steps.csv',index=False)

    p=np.mod(fin.theta.to_numpy()/np.pi,1.0); p=np.sort(p); gaps=np.diff(np.r_[p,p[0]+1.0])
    vals=np.c_[fin.a2/fin.r2,fin.b2/fin.r2,fin.ab/fin.r2]
    summary={
        'final_phase_mod_pi_min_gap':float(gaps.min()),'final_phase_mod_pi_max_gap':float(gaps.max()),
        'final_phase_mod_pi_mean_gap':float(gaps.mean()),'final_phase_mod_pi_gap_std':float(gaps.std()),
        'final_triplet_clusters_tol_1e-2':cluster_count(vals,1e-2)[0],
        'final_triplet_clusters_tol_1e-4':cluster_count(vals,1e-4)[0],
        'final_triplet_clusters_tol_1e-6':cluster_count(vals,1e-6)[0],
    }
    (out/'N16_phase_structure_summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')

    # H_perp is stored in the decompactification geometry summary, not in
    # N16_global_summary.csv.  Prefer it when available; retain compatibility
    # with a future global summary that may include H_perp directly.
    if 'H_perp' in gl.columns:
        hp_df=gl[['step','H_perp']].copy()
    else:
        geom_path=inp/'decompact_N16_geometry_summary.csv'
        if not geom_path.exists():
            raise FileNotFoundError('H_perp requires decompact_N16_geometry_summary.csv when N16_global_summary.csv lacks H_perp')
        hp_df=pd.read_csv(geom_path)[['step','H_perp']]
    steps=hp_df.step.to_numpy(int); hp=hp_df.H_perp.to_numpy(float); final=float(hp[-1]); ms=[]
    for frac in [0.5,0.9,0.95,0.99]:
        ix=np.flatnonzero(hp>=frac*final); ms.append([f'H_perp >= {int(frac*100)}% final',int(steps[ix[0]]) if len(ix) else None])
    spread=(gl.r2_max.to_numpy()-gl.r2_min.to_numpy())/((gl.r2_max.to_numpy()+gl.r2_min.to_numpy())/2)
    for thr in [1e-1,1e-2,1e-3,1e-4,1e-6,1e-8,1e-10]: ms.append([f'r2 relative spread < {thr:g} forever',forever_step(steps,spread,thr)])
    pd.DataFrame(ms,columns=['metric','step']).to_csv(out/'N16_time_separation_milestones.csv',index=False)

if __name__=='__main__': main()
