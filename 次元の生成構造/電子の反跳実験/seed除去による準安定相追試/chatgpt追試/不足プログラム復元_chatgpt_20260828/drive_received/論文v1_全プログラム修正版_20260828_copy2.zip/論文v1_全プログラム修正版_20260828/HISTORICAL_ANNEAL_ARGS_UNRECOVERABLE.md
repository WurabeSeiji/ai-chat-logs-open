# B-6 historical annealing arguments: recovery status

The original `anneal_subsets.cpp` source was recovered. The archived B-6 package also preserves the resulting best-residual table, but it does **not** preserve the command line used for `k>=7` (the exact `steps` and RNG `seed`). The package README/ANALYSIS records only the method: multi-start simulated annealing + 1-swap local descent.

I searched the mounted Drive copy, the saved package contents, indexed prior files, and available prior-context records. No trustworthy historical command log containing the missing `(N,k,steps,seed)` tuples was found. Therefore this package does **not** label any guessed values as historical.

For a deterministic fresh rerun, `reconstructed_validated/anneal_args_reconstructed.csv` supplies explicit replacement values. Every row is labeled `reconstructed_not_historical`. `B6_run_searches_reconstructed.sh` uses only that replacement table.

Historical numerical results remain available in the archived `N14_N16_all_cardinalities_best_results.csv`; the deterministic rerun may find equal or better heuristic minima, but heuristic equality to the historical k>=7 rows is not guaranteed because the original RNG schedule is missing.
