# Validation report — 2026-08-28

保存済み旧出力を参照値として、再構成生成器を機械比較した。

## 構文・ビルド

- 全 Python: `python3 -m py_compile` PASS。
- recovered `exact_k234.cpp`, `anneal_subsets.cpp`: C++17 compile PASS。

## B-1 N=5

7 CSV 全件、列・行数・文字列一致。数値最大差は `1.11e-16` 以下。

- `N5_all_steps_a_b_a2_b2_ab.csv`: exact numeric match (max diff 0)
- `N5_final_four_group_pattern_by_step.csv`: max diff 0
- `N5_key_step_ab2_ab_classes.csv`: max diff 1.11e-16
- `N5_relation_class_counts_by_step.csv`: max diff 0
- `N5_step5000_four_group_summary.csv`: max diff 0
- `N5_time_separation_milestones.csv`: exact match
- `N5_inflation_vs_ordering_timeseries.csv`: max diff 3.39e-21

重要閾値も旧保存値どおり: four-group error が以後ずっと `1e-4` 未満になる step = **2627**、`1e-8` 未満 = **4923**。

## B-2 N=16

要求 4 出力を旧保存値と比較。

- normalized final edges: exact match
- milestones: exact match
- selected triplet cluster counts: exact DataFrame equality (105 x 3)
- phase summary JSON: max numeric diff 1.11e-16

## B-3 N=3/N=4

6 CSV はすべて列・行数一致。最大数値差 5.0e-16 以下。PNG 6 枚は同じ再生成 CSV から作成できることを確認。

## B-4 comparison summaries

6 件すべて旧保存 CSV と一致:
`N3_N4`, `N6_N7`, `N8_N9`, `N10_N11`, `N12_N13`, `N14_N15`。

注: 現在の Drive 上で `N15_triplet_cluster_counts.csv` 単体が 404 になっていたため、N14/N15 の検証だけは保存済み comparison summary の N15 counts (105,65) を validation fixture として使用した。原本 `run_N14_N15_complete_analysis.py` は回収済みで、通常の再実行では当該 CSV を生成する。

## B-5 nontrivial closure

- exhaustive small subset classification: 69 x 7。旧保存表とエッジ文字列まで一致、数値差は丸め誤差レベル (`<=2.22e-16`、residual `<=8.3e-25`)。
- N=5 nontrivial pair exact covers: 12 x 4、旧保存表と **DataFrame exact equality**。
- k>=5 MITM / N16 k=4 large search はこの validation pass では全系列を再実行していない。アルゴリズム原本と結果表は同梱し、B-6 と分離して扱う。

## B-6 annealing caveat

historical `steps,seed` は旧 package / mounted Drive / indexed saved files / available prior-context から回収できなかった。したがって `anneal_args_reconstructed.csv` は明示的に `reconstructed_not_historical` としている。これは唯一の未回収情報であり、歴史的引数を推測で偽装していない。

## B-7

`N3_N16_zero_subset_exact_covers.csv` は旧 `N3_N16_zero_triple_exact_covers.csv` と **DataFrame exact equality** (17 x 8)。

## 図

旧一回限り作図コードが無い図は、再生成数表から同じ意味内容の図を作る。ピクセル同一性は検証対象外。
