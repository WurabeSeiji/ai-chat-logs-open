#!/usr/bin/env python3
from __future__ import annotations
import argparse, itertools, math, time
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.spatial import cKDTree

TOL=1e-6

def incidence(N,d):
    A=np.zeros((N,len(d)))
    for e,r in d.reset_index(drop=True).iterrows():
        A[int(r.i)-1,e]=1;A[int(r.j)-1,e]=1
    return A

def star_span_test(mask,A,tol=1e-10):
    c=np.linalg.lstsq(A.T,mask.astype(float),rcond=None)[0]
    err=np.linalg.norm(A.T@c-mask)
    return bool(err<tol),float(err)

def residual(q,idx):
    idx=np.asarray(idx,int); return float(abs(q[idx].sum())/np.abs(q[idx]).sum())

def edge_string(d,idx): return ','.join(f'{int(d.iloc[e].i)}-{int(d.iloc[e].j)}' for e in idx)

def load_sources(root):
    out={}
    for N in range(3,17):
        p=root/f'SOURCE_N{N}_step5000_final_edges.csv'
        if not p.exists(): raise FileNotFoundError(p)
        out[N]=pd.read_csv(p).sort_values('edge_index').reset_index(drop=True)
    return out

def small_classification(src):
    rows=[]
    for N,d in src.items():
        q=d.z2_re.to_numpy()+1j*d.z2_im.to_numpy(); A=incidence(N,d); M=len(d)
        for k in range(2,min(5,M-1)+1):
            if math.comb(M,k)>2_500_000: continue
            for idx in itertools.combinations(range(M),k):
                r=residual(q,idx)
                if r<TOL:
                    mask=np.zeros(M,bool);mask[list(idx)]=True;triv,err=star_span_test(mask,A)
                    rows.append([N,M,k,r,triv,err,edge_string(d,idx)])
    return pd.DataFrame(rows,columns=['N','M','k','residual','star_span_trivial','star_span_error','edges'])

def comb_array(n,k):
    return np.fromiter((x for c in itertools.combinations(range(n),k) for x in c),dtype=np.int16,count=math.comb(n,k)*k).reshape(-1,k)

def mitm_best(d,k,neighbors=16,batch=25000):
    z=d.z2_re.to_numpy()+1j*d.z2_im.to_numpy(); absz=np.abs(z); n=len(z)
    p=k//2;q=k-p;A=comb_array(n,p);B=comb_array(n,q);SB=z[B].sum(axis=1);tree=cKDTree(np.c_[SB.real,SB.imag])
    br=1e99;bi=None
    for s in range(0,len(A),batch):
        X=A[s:s+batch];SA=z[X].sum(axis=1);_,ids=tree.query(np.c_[-SA.real,-SA.imag],k=min(neighbors,len(B)))
        if ids.ndim==1:ids=ids[:,None]
        for row,a in enumerate(X):
            aset=set(map(int,a))
            for bj in ids[row]:
                b=B[int(bj)]
                if any(int(x) in aset for x in b):continue
                idx=tuple(sorted(aset|set(map(int,b))))
                if len(idx)!=k:continue
                rr=residual(z,idx)
                if rr<br:br=rr;bi=idx
    return float(br),tuple(bi)

def exact_best(d,k):
    z=d.z2_re.to_numpy()+1j*d.z2_im.to_numpy();best=(1e99,None)
    for idx in itertools.combinations(range(len(d)),k):
        r=residual(z,idx)
        if r<best[0]:best=(r,idx)
    return best

def pair_exact_covers(d,cls):
    q=d.z2_re.to_numpy()+1j*d.z2_im.to_numpy(); M=len(d)
    pairs=[]
    for _,r in cls[(cls.N==5)&(cls.k==2)&(~cls.star_span_trivial)].iterrows():
        toks=r.edges.split(','); emap={f'{int(x.i)}-{int(x.j)}':i for i,x in d.iterrows()};idx=tuple(sorted(emap[x] for x in toks));pairs.append((float(r.residual),idx))
    by={i:[] for i in range(M)}
    for pi,p in enumerate(pairs):
        for e in p[1]:by[e].append(pi)
    sols=[]
    def rec(used,chosen):
        if len(used)==M:sols.append(chosen.copy());return
        if len(sols)>=100:return
        e=min([x for x in range(M) if x not in used],key=lambda x:sum(1 for pi in by[x] if not(set(pairs[pi][1])&used)))
        for pi in by[e]:
            block=set(pairs[pi][1])
            if not block&used:rec(used|block,chosen+[pi])
    rec(set(),[])
    rows=[]
    for sol in sols:
        blocks=[];rs=[]
        for pi in sol:
            rs.append(pairs[pi][0]);blocks.append('+'.join(f'{int(d.iloc[e].i)}-{int(d.iloc[e].j)}' for e in pairs[pi][1]))
        # Historical file canonicalized each exact cover by lexicographic block order.
        pair_blocks=' | '.join(sorted(blocks))
        rows.append([len(sol),max(rs),pair_blocks])
    rows.sort(key=lambda x:x[2])
    return pd.DataFrame([[ci,*r] for ci,r in enumerate(rows)],columns=['cover_id','blocks','max_block_residual','pair_blocks'])

def history_residual(path,edge_names,N):
    d=pd.read_csv(path); emap=[(i,j) for i in range(1,N+1) for j in range(i+1,N+1)]
    targets={tuple(map(int,x.split('-'))) for x in edge_names}
    if 'i' not in d.columns:
        idx=[k for k,e in enumerate(emap) if e in targets]; use=d[d.edge_index.isin(idx)].copy()
    else: use=d[d.apply(lambda r:(int(r.i),int(r.j)) in targets,axis=1)].copy()
    if 'z2_re' not in use.columns: use['z2_re']=use.a2-use.b2;use['z2_im']=2*use.ab
    rows=[]
    for t,g in use.groupby('step',sort=True):
        q=g.z2_re.to_numpy()+1j*g.z2_im.to_numpy();rows.append([int(t),float(abs(q.sum())/np.abs(q).sum())])
    return pd.DataFrame(rows,columns=['step','residual'])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-dir',type=Path,required=True,help='Directory containing SOURCE_N{3..16}_step5000_final_edges.csv')
    ap.add_argument('--output-dir',type=Path,default=Path('.'))
    ap.add_argument('--n5-history',type=Path,default=None,help='N5_all_steps_a_b_a2_b2_ab.csv or N5_all_steps_long.csv')
    ap.add_argument('--n14-history',type=Path,default=None,help='N14_all_steps_long.csv')
    a=ap.parse_args();out=a.output_dir;out.mkdir(parents=True,exist_ok=True);src=load_sources(a.source_dir)

    cls=small_classification(src);cls.to_csv(out/'N3_N16_small_subset_closure_classification.csv',index=False)

    # Historical MITM scope.
    mr=[]
    for N in range(6,14):
        ks=[6] if N<=9 else [5,6]
        for k in ks:
            t=time.time();r,idx=mitm_best(src[N],k);mr.append([N,len(src[N]),k,r,edge_string(src[N],idx),time.time()-t])
    mitm=pd.DataFrame(mr,columns=['N','M','k','best_residual','edges','runtime_s']);mitm.to_csv(out/'MITM_N6_N13_k5_k6.csv',index=False)

    tr=[]
    for N,k,mode in [(14,6,'mitm'),(15,6,'mitm'),(16,4,'exact'),(16,5,'mitm'),(16,6,'mitm')]:
        t=time.time();r,idx=(mitm_best(src[N],k) if mode=='mitm' else exact_best(src[N],k));tr.append([N,len(src[N]),k,r,edge_string(src[N],idx),time.time()-t])
    targ=pd.DataFrame(tr,columns=['N','M','k','best_residual','edges','runtime_s']);targ.to_csv(out/'targeted_MITM_N14_N16.csv',index=False)

    # Summary from exhaustive small hits.
    srows=[]
    for N in range(3,17):
        x=cls[cls.N==N];nt=x[~x.star_span_trivial]
        if len(nt):
            b=nt.sort_values('residual').iloc[0];srows.append([N,len(src[N]),len(x),len(nt),int(nt.k.min()),float(b.residual),b.edges])
        else:srows.append([N,len(src[N]),len(x),0,None,None,None])
    sm=pd.DataFrame(srows,columns=['N','M','small_zero_hits','nontrivial_small_zero_hits','min_nontrivial_k','best_nontrivial_residual','best_nontrivial_edges']);sm.to_csv(out/'N3_N16_nontrivial_closure_summary.csv',index=False)
    asses=[]
    n14=targ[(targ.N==14)&(targ.k==6)].iloc[0]
    for N in range(3,17):
        if N==5:
            b=sm[sm.N==5].iloc[0]; asses.append([N,len(src[N]),2,b.best_nontrivial_residual,'robust nontrivial closure'])
        elif N==14: asses.append([N,len(src[N]),6,float(n14.best_residual),'persistent numerical quasi-closure candidate'])
        else: asses.append([N,len(src[N]),None,None,'none found'])
    pd.DataFrame(asses,columns=['N','M','nontrivial_k','best_residual','assessment']).to_csv(out/'N3_N16_nontrivial_closure_assessment.csv',index=False)

    covers=pair_exact_covers(src[5],cls);covers.to_csv(out/'N5_nontrivial_pair_exact_covers.csv',index=False)

    n5hist=n14hist=None
    if a.n5_history:
        b=sm[sm.N==5].iloc[0]; names=b.best_nontrivial_edges.split(',');n5hist=history_residual(a.n5_history,names,5);n5hist.to_csv(out/'N5_best_nontrivial_pair_time_evolution.csv',index=False)
    if a.n14_history:
        names=n14.edges.split(',');n14hist=history_residual(a.n14_history,names,14);n14hist.to_csv(out/'N14_best_k6_candidate_time_evolution.csv',index=False)

    # Figures.
    fig,ax=plt.subplots(figsize=(9,5)); ax.plot(sm.N,sm.small_zero_hits,marker='o',label='small zero hits');ax.plot(sm.N,sm.nontrivial_small_zero_hits,marker='o',label='nontrivial hits');ax.set_xlabel('N');ax.set_ylabel('count');ax.legend();ax.set_title('Trivial vs nontrivial small closures');fig.tight_layout();fig.savefig(out/'N3_N16_trivial_vs_nontrivial_small_closures.png',dpi=180);plt.close(fig)

    fig,ax=plt.subplots(figsize=(7,6));ang=np.linspace(0,2*np.pi,6)[:-1];pts={i+1:(np.cos(ang[i]),np.sin(ang[i])) for i in range(5)}
    bestpairs=cls[(cls.N==5)&(cls.k==2)&(~cls.star_span_trivial)].sort_values('residual')
    for _,r in bestpairs.iterrows():
        for tok in r.edges.split(','):
            i,j=map(int,tok.split('-'));x1,y1=pts[i];x2,y2=pts[j];ax.plot([x1,x2],[y1,y2],alpha=.25)
    for i,(x,y) in pts.items():ax.scatter([x],[y],s=80);ax.text(x+.03,y+.03,str(i))
    ax.axis('equal');ax.axis('off');ax.set_title('N=5 nontrivial 2-edge closure graph');fig.tight_layout();fig.savefig(out/'N5_nontrivial_pair_closure_graph.png',dpi=180);plt.close(fig)

    if n5hist is not None and n14hist is not None:
        fig,ax=plt.subplots(figsize=(9,5));ax.semilogy(n5hist.step,np.maximum(n5hist.residual,1e-16),label='N=5 best 2-edge');ax.semilogy(n14hist.step,np.maximum(n14hist.residual,1e-16),label='N=14 k=6 candidate');ax.axhline(1e-6,ls='--',lw=.8);ax.axhline(1e-8,ls='--',lw=.8);ax.legend();ax.set_xlabel('step');ax.set_ylabel('closure residual');ax.set_title('N=5 exact-like closure vs N=14 quasi-closure');fig.tight_layout();fig.savefig(out/'N5_vs_N14_nontrivial_closure_time_evolution.png',dpi=180);plt.close(fig)

if __name__=='__main__':main()
