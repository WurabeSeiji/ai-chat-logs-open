#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# These are not guessed search results.  They are the candidates recorded in the
# archived B-5/B-6 result tables.
N14_HISTORICAL_K6 = ['1-7','2-14','4-10','5-9','5-14','10-13']

def load_b5():
    here=Path(__file__).resolve().parent
    p=here/'B5_generate_nontrivial_zero_closure_outputs.py'
    spec=importlib.util.spec_from_file_location('b5_shared',p)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

def main():
    ap=argparse.ArgumentParser(description='Generate the B-6 shared N=5 benchmark/exact-cover files and N=14 k=6 candidate time evolution.')
    ap.add_argument('--source-dir',type=Path,required=True,help='Directory with SOURCE_N3..16_step5000_final_edges.csv (B-5 source set)')
    ap.add_argument('--n5-history',type=Path,required=True,help='N5_all_steps_a_b_a2_b2_ab.csv or compatible long history')
    ap.add_argument('--n14-history',type=Path,required=True,help='N14_all_steps_long.csv')
    ap.add_argument('--output-dir',type=Path,default=Path('.'))
    a=ap.parse_args(); a.output_dir.mkdir(parents=True,exist_ok=True)
    b5=load_b5(); src=b5.load_sources(a.source_dir)
    cls=b5.small_classification(src)
    covers=b5.pair_exact_covers(src[5],cls)
    covers.to_csv(a.output_dir/'N5_nontrivial_pair_exact_covers.csv',index=False)
    best=cls[(cls.N==5)&(cls.k==2)&(~cls.star_span_trivial)].sort_values('residual').iloc[0]
    n5=b5.history_residual(a.n5_history,str(best.edges).split(','),5)
    n14=b5.history_residual(a.n14_history,N14_HISTORICAL_K6,14)
    n5.to_csv(a.output_dir/'N5_best_nontrivial_pair_time_evolution.csv',index=False)
    n14.to_csv(a.output_dir/'N14_best_k6_candidate_time_evolution.csv',index=False)
    fig,ax=plt.subplots(figsize=(9,5))
    ax.semilogy(n5.step,np.maximum(n5.residual,1e-16),label='N=5 best nontrivial pair')
    ax.semilogy(n14.step,np.maximum(n14.residual,1e-16),label='N=14 k=6 candidate')
    ax.axhline(1e-6,ls='--',lw=.8); ax.axhline(1e-8,ls='--',lw=.8)
    ax.set_xlabel('step'); ax.set_ylabel('normalized closure residual'); ax.legend()
    ax.set_title('N=14 candidate vs N=5 benchmark time evolution')
    fig.tight_layout(); fig.savefig(a.output_dir/'N14_candidate_vs_N5_benchmark_time_evolution.png',dpi=180); plt.close(fig)

if __name__=='__main__': main()
