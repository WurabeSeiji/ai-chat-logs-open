#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

TOL=1e-8

def circdist(a,b):
    d=abs(a-b)%1.0
    return min(d,1.0-d)

def cluster_scalar(values,tol=TOL):
    centers=[]; members=[]
    for idx,x in enumerate(values):
        hit=None
        for ci,c in enumerate(centers):
            if circdist(float(x),float(c))<tol: hit=ci; break
        if hit is None: centers.append(float(x)); members.append([idx])
        else: members[hit].append(idx)
    # circular mean is unnecessary for tiny within-class spreads; use phase of unit-circle mean.
    out=[]
    for inds in members:
        z=np.mean(np.exp(2j*np.pi*np.asarray(values)[inds]))
        out.append(float(np.angle(z)/(2*np.pi)%1.0))
    return out,members

def pairwise_classes(p,tol=TOL):
    vals=[]
    for i in range(len(p)):
        for j in range(i+1,len(p)): vals.append(circdist(float(p[i]),float(p[j])))
    vals=sorted(vals)
    groups=[]
    for v in vals:
        if not groups or abs(v-np.mean(groups[-1]))>=tol: groups.append([v])
        else: groups[-1].append(v)
    return [(float(np.mean(g)),len(g)) for g in groups]

def circle_plot(p,labels,title,out):
    fig,ax=plt.subplots(figsize=(6,6)); th=np.linspace(0,2*np.pi,500);ax.plot(np.cos(th),np.sin(th),lw=.8)
    for x,l in zip(p,labels):
        w=np.exp(2j*np.pi*x);ax.scatter([w.real],[w.imag]);ax.annotate(l,(w.real,w.imag),fontsize=8)
    ax.set_aspect('equal');ax.axis('off');ax.set_title(title);fig.tight_layout();fig.savefig(out,dpi=180);plt.close(fig)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input-dir',type=Path,default=Path('.'));ap.add_argument('--output-dir',type=Path,default=Path('.'))
    a=ap.parse_args();inp=a.input_dir;out=a.output_dir;out.mkdir(parents=True,exist_ok=True)
    d3=pd.read_csv(inp/'N3_all_steps_long.csv'); d4=pd.read_csv(inp/'N4_all_steps_long.csv')

    # N=3 final phase classes and pairwise phase-difference classes.
    f3=d3[d3.step==5000].sort_values('edge_index').reset_index(drop=True); p3=np.mod(f3.theta.to_numpy()/np.pi,1.0)
    c3,m3=cluster_scalar(p3)
    rows=[]
    for ci,(c,inds) in enumerate(zip(c3,m3)):
        edges=','.join(f'{int(f3.iloc[i].i)}-{int(f3.iloc[i].j)}' for i in inds)
        rows.append([ci,len(inds),c,edges])
    pd.DataFrame(rows,columns=['class_id','count','theta_over_pi_mod1','edges']).to_csv(out/'N3_final_phase_classes.csv',index=False)
    pd.DataFrame(pairwise_classes(p3),columns=['abs_delta_theta_over_pi','count']).to_csv(out/'N3_pairwise_phase_difference_classes.csv',index=False)

    conv=[]
    for t,g in d3.groupby('step',sort=True):
        p=np.mod(g.sort_values('edge_index').theta.to_numpy()/np.pi,1.0)
        ds=[]
        for i in range(len(p)):
            for j in range(i+1,len(p)): ds.append(circdist(p[i],p[j]))
        er=np.abs(np.asarray(ds)-1/3)
        conv.append([int(t),float(er.max()),float(er.mean())])
    cdf=pd.DataFrame(conv,columns=['step','max_abs_error_from_one_third','mean_abs_error_from_one_third'])
    cdf.to_csv(out/'N3_phase_difference_convergence_to_one_third.csv',index=False)

    fig,ax=plt.subplots(figsize=(8,5));ax.semilogy(cdf.step,np.maximum(cdf.max_abs_error_from_one_third,1e-16),label='max error');ax.semilogy(cdf.step,np.maximum(cdf.mean_abs_error_from_one_third,1e-16),label='mean error');ax.set_xlabel('step');ax.set_ylabel('error from 1/3');ax.legend();ax.set_title('N=3 phase differences -> one third');fig.tight_layout();fig.savefig(out/'N3_phase_convergence_to_one_third.png',dpi=180);plt.close(fig)
    circle_plot(p3,[f'{int(r.i)}-{int(r.j)}' for _,r in f3.iterrows()],'N=3 final edge phases mod pi',out/'N3_triangle_phase_classes.png')
    z3=(f3.z2_re.to_numpy()+1j*f3.z2_im.to_numpy())/f3.r2.to_numpy();circle_plot((np.angle(z3)/(2*np.pi))%1,[f'{int(r.i)}-{int(r.j)}' for _,r in f3.iterrows()],'N=3 final normalized z^2 phases',out/'N3_final_z2_phase_circle.png')

    # N=4 opposite edges: (12,34), (13,24), (14,23).
    f4=d4[d4.step==5000].sort_values('edge_index').reset_index(drop=True); p4=np.mod(f4.theta.to_numpy()/np.pi,1.0)
    c4,m4=cluster_scalar(p4)
    rows=[]
    for ci,(c,inds) in enumerate(zip(c4,m4)):
        edges=','.join(f'{int(f4.iloc[i].i)}-{int(f4.iloc[i].j)}' for i in inds)
        rows.append([ci,len(inds),c,edges])
    pd.DataFrame(rows,columns=['class_id','count','theta_over_pi_mod1','edges']).to_csv(out/'N4_final_phase_classes.csv',index=False)
    pd.DataFrame(pairwise_classes(p4),columns=['abs_delta_theta_over_pi','count']).to_csv(out/'N4_pairwise_phase_difference_classes.csv',index=False)

    edge_to_index={(int(r.i),int(r.j)):idx for idx,r in f4.iterrows()}
    opp=[[(1,2),(3,4)],[(1,3),(2,4)],[(1,4),(2,3)]]
    orows=[]
    for t,g0 in d4.groupby('step',sort=True):
        g=g0.sort_values('edge_index').reset_index(drop=True); p=np.mod(g.theta.to_numpy()/np.pi,1.0)
        pairph=[]; within=[]
        for pair in opp:
            ids=[edge_to_index[e] for e in pair]
            within.append(circdist(p[ids[0]],p[ids[1]]))
            z=np.mean(np.exp(2j*np.pi*p[ids]));pairph.append(float(np.angle(z)/(2*np.pi)%1.0))
        sp=sorted(pairph); gaps=[sp[1]-sp[0],sp[2]-sp[1],sp[0]+1-sp[2]]
        orows.append([int(t),max(within),max(abs(np.asarray(gaps)-1/3)),*gaps])
    odf=pd.DataFrame(orows,columns=['step','max_within_opposite_pair_phase_diff','max_class_gap_error_from_one_third','gap1','gap2','gap3'])
    odf.to_csv(out/'N4_opposite_edge_phase_ordering.csv',index=False)
    fig,ax=plt.subplots(figsize=(8,5));ax.semilogy(odf.step,np.maximum(odf.max_class_gap_error_from_one_third,1e-16),label='gap error');ax.semilogy(odf.step,np.maximum(odf.max_within_opposite_pair_phase_diff,1e-16),label='opposite-pair mismatch');ax.legend();ax.set_xlabel('step');ax.set_ylabel('error');ax.set_title('N=4 opposite-edge phase ordering');fig.tight_layout();fig.savefig(out/'N4_phase_ordering.png',dpi=180);plt.close(fig)

    # Tetrahedron edge sketch, labels carry final phase class.
    pts={1:(0,1.1),2:(-1,-.65),3:(1,-.65),4:(0,.05)}
    fig,ax=plt.subplots(figsize=(7,6))
    for idx,r in f4.iterrows():
        i,j=int(r.i),int(r.j);x1,y1=pts[i];x2,y2=pts[j];ax.plot([x1,x2],[y1,y2]);ax.text((x1+x2)/2,(y1+y2)/2,f'{i}-{j}\n{p4[idx]:.3f}',fontsize=7)
    for i,(x,y) in pts.items():ax.scatter([x],[y],s=80);ax.text(x+.04,y+.04,str(i))
    ax.axis('equal');ax.axis('off');ax.set_title('N=4 tetrahedron: opposite-edge phase classes');fig.tight_layout();fig.savefig(out/'N4_tetrahedron_opposite_edge_classes.png',dpi=180);plt.close(fig)
    z4=(f4.z2_re.to_numpy()+1j*f4.z2_im.to_numpy())/f4.r2.to_numpy();circle_plot((np.angle(z4)/(2*np.pi))%1,[f'{int(r.i)}-{int(r.j)}' for _,r in f4.iterrows()],'N=4 final normalized z^2 phases',out/'N4_final_z2_phase_circle.png')

if __name__=='__main__':main()
