#!/bin/sh
set -eu
if [ "$#" -ne 2 ]; then
  echo "usage: $0 ORIGINAL_PACKAGES_ROOT OUTPUT_ROOT" >&2
  exit 2
fi
ROOT=$1
OUT=$2
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$OUT" "$OUT/B1" "$OUT/B2" "$OUT/B3" "$OUT/B4" "$OUT/B5" "$OUT/B6" "$OUT/B7"

python3 "$HERE/reconstructed_validated/B1_generate_N5_complete_analysis.py" \
  --input-dir "$ROOT/N5_complex_simplex_complete_analysis_20260826" --output-dir "$OUT/B1"
python3 "$HERE/reconstructed_validated/B2_generate_N16_phase_outputs.py" \
  --input-dir "$ROOT/N16_complex_simplex_complete_analysis_20260826" --output-dir "$OUT/B2"
python3 "$HERE/reconstructed_validated/B3_generate_N3_N4_phase_outputs.py" \
  --input-dir "$ROOT/N3_N4_complex_simplex_complete_analysis_20260826" --output-dir "$OUT/B3"
cp "$OUT/B3/N3_phase_difference_convergence_to_one_third.csv" "$OUT/B4/"
cp "$OUT/B3/N4_opposite_edge_phase_ordering.csv" "$OUT/B4/"
python3 "$HERE/reconstructed_validated/B4_generate_pair_comparison_summaries.py" \
  --root "$ROOT" --output-dir "$OUT/B4"
python3 "$HERE/reconstructed_validated/B5_generate_nontrivial_zero_closure_outputs.py" \
  --source-dir "$ROOT/N3_N16_nontrivial_zero_closure_analysis_20260826" \
  --n5-history "$ROOT/N5_complex_simplex_complete_analysis_20260826/N5_all_steps_a_b_a2_b2_ab.csv" \
  --n14-history "$ROOT/N14_N15_complex_simplex_complete_analysis_20260826/N14_all_steps_long.csv" \
  --output-dir "$OUT/B5"
python3 "$HERE/reconstructed_validated/B6_generate_shared_time_evolution.py" \
  --source-dir "$ROOT/N3_N16_nontrivial_zero_closure_analysis_20260826" \
  --n5-history "$ROOT/N5_complex_simplex_complete_analysis_20260826/N5_all_steps_a_b_a2_b2_ab.csv" \
  --n14-history "$ROOT/N14_N15_complex_simplex_complete_analysis_20260826/N14_all_steps_long.csv" \
  --output-dir "$OUT/B6"
python3 "$HERE/reconstructed_validated/B7_generate_zero_subset_exact_covers.py" \
  --source-dir "$ROOT/N3_N16_partial_zero_closure_analysis_20260826" \
  --output "$OUT/B7/N3_N16_zero_subset_exact_covers.csv"

# B-6 all-cardinality search is intentionally opt-in because historical anneal
# steps/seeds were not preserved. RUN_B6_SEARCH=1 uses the explicitly labelled
# reconstructed deterministic schedule.
if [ "${RUN_B6_SEARCH:-0}" = "1" ]; then
  "$HERE/reconstructed_validated/B6_run_searches_reconstructed.sh" \
    "$ROOT/N3_N16_nontrivial_zero_closure_analysis_20260826" "$OUT/B6/search"
fi
