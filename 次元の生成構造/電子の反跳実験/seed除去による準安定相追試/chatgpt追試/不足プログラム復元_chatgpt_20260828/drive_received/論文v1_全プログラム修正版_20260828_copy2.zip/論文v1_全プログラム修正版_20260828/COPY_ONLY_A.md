# A. 生成スクリプト不要のコピー項目

この ZIP の主目的は B-1〜B-7 の欠落生成プログラム回収・再構成である。A 群は計算ではなくコピーなので、次の規則で `run_all` 側へ組み込めばよい。

1. `SOURCE_N{3..16}_step5000_final_edges.csv`
   - N=3,4: `N3_N4_complex_simplex_complete_analysis_20260826/N{N}_step5000_final_edges.csv`
   - N=5: `N5_complex_simplex_complete_analysis_20260826/N5_step5000_final_edges.csv`（無ければ B-1 の step=5000 行から同じ long schema を作る）
   - N=6..15: 対応する `N*_N*_complex_simplex_complete_analysis_20260826/N{N}_step5000_final_edges.csv`
   - N=16: `N16_complex_simplex_complete_analysis_20260826/N16_step5000_final_edges.csv`
   - これらを partial / nontrivial 解析パッケージへ同名 `SOURCE_...` としてコピー。N=14..16 は complete nontrivial search にもコピー。
2. N16 decompact 3 CSV
   - `complex_simplex_decompactification_N5_N16_20260826/results/N16_geometry_summary.csv` -> `decompact_N16_geometry_summary.csv`
   - `.../N16_perp_axis_growth_rates.csv` -> `decompact_N16_perp_axis_growth_rates.csv`
   - `.../N16_takagi_axes.csv` -> `decompact_N16_takagi_axes.csv`
3. `N5_raw_K_raw_observables.csv`: K-sigma audit packageの同名 raw-K 出力を N5 complete package へコピー。
4. `N14_best_k6_candidate_time_evolution.csv`, `N5_best_nontrivial_pair_time_evolution.csv`, `N5_nontrivial_pair_exact_covers.csv` は B-5/B-6 共用。同じ生成結果を必要パッケージへコピーしてよい。

コピーそのものに新しい物理計算はないため、SHA256 をコピー前後で照合する。
