#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

GROUPS = {
    "A_plus": [0, 1, 9],
    "A_minus": [2, 3, 4],
    "B_plus": [5, 8],
    "B_minus": [6, 7],
}
EDGE_NAMES = ["1-2","1-3","1-4","1-5","2-3","2-4","2-5","3-4","3-5","4-5"]
KEY_STEPS = [0,1,10,50,81,82,100,200,500,1000,2000,3000,4000,5000]
KEY_CLUSTER_TOL = 1e-10


def cluster_rows(vals: np.ndarray, tol: float):
    centers: list[np.ndarray] = []
    members: list[list[int]] = []
    for idx, vv in enumerate(vals):
        hit = None
        for ci, c in enumerate(centers):
            if np.max(np.abs(vv - c)) < tol:
                hit = ci
                break
        if hit is None:
            centers.append(vv.copy()); members.append([idx])
        else:
            members[hit].append(idx)
    return centers, members


def forever_step(steps: np.ndarray, values: np.ndarray, threshold: float):
    # First step at which the condition remains true through the final sample.
    suffix_max = np.maximum.accumulate(values[::-1])[::-1]
    idx = np.flatnonzero(suffix_max < threshold)
    return int(steps[idx[0]]) if len(idx) else None


def make_infographic(out: Path, title: str, lines: list[str]):
    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_axes([0.05,0.05,0.90,0.90]); ax.axis('off')
    ax.text(0.02,0.96,title,va='top',fontsize=18,weight='bold')
    y=0.88
    for line in lines:
        ax.text(0.03,y,line,va='top',fontsize=11,wrap=True)
        y-=0.07
    fig.savefig(out,dpi=180,bbox_inches='tight'); plt.close(fig)


def main():
    ap=argparse.ArgumentParser(description='Reconstruct the missing N=5 derived tables and figures from saved phase-by-edge and raw-observable CSVs.')
    ap.add_argument('--input-dir',type=Path,default=Path('.'))
    ap.add_argument('--output-dir',type=Path,default=Path('.'))
    a=ap.parse_args(); inp=a.input_dir; out=a.output_dir; out.mkdir(parents=True,exist_ok=True)

    phase=pd.read_csv(inp/'N5_phase_by_edge_5000steps.csv')
    obs=pd.read_csv(inp/'N5_raw_K_raw_observables.csv')
    required={'step','edge_index','theta','relative_theta_over_pi_mod_pi','amplitude'}
    if not required.issubset(phase.columns): raise ValueError(f'phase CSV missing {required-set(phase.columns)}')

    d=phase.copy()
    d['a']=d.amplitude*np.cos(d.theta); d['b']=d.amplitude*np.sin(d.theta)
    d['a2']=d.a*d.a; d['b2']=d.b*d.b; d['ab']=d.a*d.b; d['r2']=d.a2+d.b2
    d['a2_norm']=d.a2/d.r2; d['b2_norm']=d.b2/d.r2; d['ab_norm']=d.ab/d.r2
    d['z2_re']=d.a2-d.b2; d['z2_im']=2*d.ab
    d['z2_phase_over_pi']=np.angle(d.z2_re.to_numpy()+1j*d.z2_im.to_numpy())/np.pi
    d['relation_class']=np.where(d.a2<d.b2,'a2<b2','a2>b2')+';'+np.where(d.ab<0,'ab<0','ab>0')
    d['constraint1']=d.a2_norm+d.b2_norm-1.0
    d['constraint2']=d.ab_norm*d.ab_norm-d.a2_norm*d.b2_norm
    cols=['step','edge_index','theta','relative_theta_over_pi_mod_pi','amplitude','a','b','a2','b2','ab','r2','a2_norm','b2_norm','ab_norm','z2_re','z2_im','z2_phase_over_pi','relation_class','constraint1','constraint2']
    d[cols].to_csv(out/'N5_all_steps_a_b_a2_b2_ab.csv',index=False)

    rc=(d.groupby(['step','relation_class']).size().unstack(fill_value=0)
          .reindex(columns=['a2<b2;ab<0','a2<b2;ab>0','a2>b2;ab<0','a2>b2;ab>0'],fill_value=0).reset_index())
    rc.to_csv(out/'N5_relation_class_counts_by_step.csv',index=False)

    four=[]
    for t,g0 in d.groupby('step',sort=True):
        g=g0.set_index('edge_index')
        centers={}; within={}
        for name,ids in GROUPS.items():
            p=g.loc[ids,['a2_norm','b2_norm','ab_norm']].to_numpy(float)
            c=p.mean(axis=0); centers[name]=c
            within[name]=float(np.max(np.abs(p-c)))
        comp=lambda c: np.array([c[1],c[0],-c[2]])
        ca=float(np.max(np.abs(centers['A_minus']-comp(centers['A_plus']))))
        cb=float(np.max(np.abs(centers['B_minus']-comp(centers['B_plus']))))
        abd=float(np.linalg.norm(centers['A_plus']-centers['B_plus']))
        A=centers['A_plus']; B=centers['B_plus']
        four.append([int(t),within['A_plus'],within['A_minus'],within['B_plus'],within['B_minus'],ca,cb,abd,*A,*B])
    fcols=['step','within_A_plus','within_A_minus','within_B_plus','within_B_minus','complement_error_A','complement_error_B','A_B_center_distance','Aplus_a2n','Aplus_b2n','Aplus_abn','Bplus_a2n','Bplus_b2n','Bplus_abn']
    f=pd.DataFrame(four,columns=fcols)
    f.to_csv(out/'N5_final_four_group_pattern_by_step.csv',index=False)

    # Key-step fine clustering. Historical table used max-coordinate distance < 1e-10.
    krows=[]
    for t in KEY_STEPS:
        g=d[d.step==t].sort_values('edge_index')
        vals=g[['a2_norm','b2_norm','ab_norm']].to_numpy(float)
        _, members=cluster_rows(vals,KEY_CLUSTER_TOL)
        for ci,inds in enumerate(members):
            c=vals[inds].mean(axis=0)
            krows.append([t,ci,len(inds),*c])
    pd.DataFrame(krows,columns=['step','class_id','count','a2_norm','b2_norm','ab_norm']).to_csv(out/'N5_key_step_ab2_ab_classes.csv',index=False)

    # Final 3+3+2+2 summary.
    fin=d[d.step==5000].set_index('edge_index')
    srows=[]
    for name,ids in GROUPS.items():
        g=fin.loc[ids]
        edges=','.join(EDGE_NAMES[i] for i in ids)
        z2p=np.angle(g.z2_re.to_numpy()+1j*g.z2_im.to_numpy())/np.pi
        srows.append([name,edges,len(ids),g.r2.mean(),g.a2.mean(),g.b2.mean(),g.ab.mean(),g.z2_re.mean(),g.z2_im.mean(),z2p.mean()])
    pd.DataFrame(srows,columns=['group','edges','count','mean_r2','mean_a2','mean_b2','mean_ab','mean_z2_re','mean_z2_im','mean_z2_phase_over_pi']).to_csv(out/'N5_step5000_four_group_summary.csv',index=False)

    # Join the dynamical observable with the ordering error.
    f2=f.copy()
    err=f2[['within_A_plus','within_A_minus','within_B_plus','within_B_minus','complement_error_A','complement_error_B']].max(axis=1)
    merged=obs[['step','H_perp','A_perp','H_total']].merge(f2[['step','A_B_center_distance']],on='step',how='inner')
    merged.insert(4,'four_group_error',err.to_numpy())
    merged.to_csv(out/'N5_inflation_vs_ordering_timeseries.csv',index=False)

    # Historical milestones.
    steps=merged.step.to_numpy(int); hp=merged.H_perp.to_numpy(float); fg=merged.four_group_error.to_numpy(float)
    ms=[]; final=float(hp[-1])
    for frac in [0.5,0.9,0.95,0.99]:
        ix=np.flatnonzero(hp>=frac*final); ms.append([f'H_perp >= {int(frac*100)}% final',int(steps[ix[0]]) if len(ix) else None])
    for thr in [1e-1,1e-2,1e-3,1e-4,1e-6,1e-8]:
        ms.append([f'four-group error < {thr:g} forever',forever_step(steps,fg,thr)])
    pd.DataFrame(ms,columns=['metric','step']).to_csv(out/'N5_time_separation_milestones.csv',index=False)

    # Figures. Numerical content is the recovered definition; layout is a reconstructed equivalent.
    z=fin.sort_index(); zn=(z.z2_re.to_numpy()+1j*z.z2_im.to_numpy())/z.r2.to_numpy()
    fig,ax=plt.subplots(figsize=(6,6)); ax.scatter(zn.real,zn.imag)
    for k,w in enumerate(zn): ax.annotate(EDGE_NAMES[k],(w.real,w.imag),fontsize=8)
    th=np.linspace(0,2*np.pi,500); ax.plot(np.cos(th),np.sin(th),lw=0.8); ax.set_aspect('equal'); ax.set_xlabel('Re(z^2)/|z|^2'); ax.set_ylabel('Im(z^2)/|z|^2'); ax.set_title('N=5 step 5000: z^2 phase classes'); fig.tight_layout(); fig.savefig(out/'N5_final_z2_classes.png',dpi=180); plt.close(fig)

    fig,ax=plt.subplots(figsize=(8,5)); ax.semilogy(f.step,np.maximum(err,1e-16),label='four-group error'); ax.semilogy(f.step,np.maximum(f.A_B_center_distance,1e-16),label='A/B center distance'); ax.axhline(1e-4,ls='--',lw=.8); ax.axhline(1e-8,ls='--',lw=.8); ax.set_xlabel('step'); ax.set_ylabel('log scale'); ax.legend(); ax.set_title('N=5: four-group convergence'); fig.tight_layout(); fig.savefig(out/'N5_four_group_convergence.png',dpi=180); plt.close(fig)

    ss=pd.DataFrame(srows,columns=['group','edges','count','mean_r2','mean_a2','mean_b2','mean_ab','mean_z2_re','mean_z2_im','mean_z2_phase_over_pi'])
    fig,ax=plt.subplots(figsize=(8,5)); x=np.arange(4); w=.25; ax.bar(x-w,ss.mean_a2/ss.mean_r2,w,label='a2/r2'); ax.bar(x,ss.mean_b2/ss.mean_r2,w,label='b2/r2'); ax.bar(x+w,ss.mean_ab/ss.mean_r2,w,label='ab/r2'); ax.set_xticks(x,ss.group); ax.legend(); ax.set_title('N=5: 3+3+2+2 family components'); fig.tight_layout(); fig.savefig(out/'N5_two_family_components.png',dpi=180); plt.close(fig)

    # Common vs differential phase readout from group mean z^2 phases.
    phs=np.angle(ss.mean_z2_re.to_numpy()+1j*ss.mean_z2_im.to_numpy())
    fig,ax=plt.subplots(figsize=(8,5)); ax.plot(np.arange(4),np.unwrap(phs)/np.pi,marker='o'); ax.set_xticks(np.arange(4),ss.group); ax.set_ylabel('unwrapped mean z^2 phase / pi'); ax.set_title('N=5: common/differential phase relation'); fig.tight_layout(); fig.savefig(out/'N5_common_vs_differential_phase_rotation.png',dpi=180); plt.close(fig)

    # Square-pyramid interpretation: fixed N=5 topology, edge labels by final group.
    coords={1:(0,1.15),2:(-1,-.55),3:(1,-.55),4:(-.65,.1),5:(.65,.1)}
    fig,ax=plt.subplots(figsize=(7,6));
    for e,(i,j) in enumerate([(1,2),(1,3),(1,4),(1,5),(2,3),(2,4),(2,5),(3,4),(3,5),(4,5)]):
        x1,y1=coords[i];x2,y2=coords[j];ax.plot([x1,x2],[y1,y2],lw=1);ax.text((x1+x2)/2,(y1+y2)/2,EDGE_NAMES[e],fontsize=7)
    for i,(x0,y0) in coords.items(): ax.scatter([x0],[y0],s=80);ax.text(x0+.04,y0+.04,str(i))
    ax.axis('equal');ax.axis('off');ax.set_title('N=5 simplex: square-pyramid interpretation (topological sketch)');fig.tight_layout();fig.savefig(out/'N5_square_pyramid_interpretation.png',dpi=180);plt.close(fig)

    m=dict(ms)
    make_infographic(out/'N5_complete_analysis_infographic.png','N=5 complete analysis',[
        'Final relation-wave classes: 3 + 3 + 2 + 2.',
        f"four-group error < 1e-4 forever: step {m.get('four-group error < 0.0001 forever')}",
        f"four-group error < 1e-8 forever: step {m.get('four-group error < 1e-08 forever')}",
        f"H_perp reaches 99% of final at step {m.get('H_perp >= 99% final')}",
        'Complement map: (a2,b2,ab) -> (b2,a2,-ab), corresponding to a 90-degree complex rotation.'
    ])
    make_infographic(out/'N5_complex_simplex_structure_infographic.png','N=5 complex simplex structure',[
        'A+: edges 1-2, 1-3, 4-5 (3)', 'A-: edges 1-4, 1-5, 2-3 (3)',
        'B+: edges 2-4, 3-5 (2)', 'B-: edges 2-5, 3-4 (2)',
        'A-/A+ and B-/B+ are approximately pi/2 rotations; z^2 changes sign.',
        'All numerical tables are regenerated from the saved phase-by-edge trajectory; no archived derived output is read.'
    ])

if __name__=='__main__': main()
