#!/usr/bin/env python3
import argparse,itertools,math,time
from pathlib import Path
import numpy as np,pandas as pd
from scipy.spatial import cKDTree

def comb_array(n,k):
    return np.fromiter((x for c in itertools.combinations(range(n),k) for x in c),dtype=np.int16,count=math.comb(n,k)*k).reshape(-1,k)
def best(d,k,neighbors=16,batch=25000):
    z=d.z2_re.to_numpy()+1j*d.z2_im.to_numpy();az=np.abs(z);n=len(z);p=k//2;q=k-p
    A=comb_array(n,p);B=comb_array(n,q);SB=z[B].sum(axis=1);tree=cKDTree(np.c_[SB.real,SB.imag]);br=1e99;bi=None
    for s in range(0,len(A),batch):
        X=A[s:s+batch];SA=z[X].sum(axis=1);_,ids=tree.query(np.c_[-SA.real,-SA.imag],k=min(neighbors,len(B)))
        if ids.ndim==1:ids=ids[:,None]
        for row,a in enumerate(X):
            aset=set(map(int,a))
            for bj in ids[row]:
                b=B[int(bj)]
                if any(int(x) in aset for x in b):continue
                idx=tuple(sorted(aset|set(map(int,b))))
                if len(idx)!=k:continue
                rr=abs(z[list(idx)].sum())/az[list(idx)].sum()
                if rr<br:br=float(rr);bi=idx
    return br,bi
def main():
    ap=argparse.ArgumentParser();ap.add_argument('N',type=int);ap.add_argument('k',type=int);ap.add_argument('source',type=Path);ap.add_argument('out',type=Path);a=ap.parse_args()
    d=pd.read_csv(a.source).sort_values('edge_index').reset_index(drop=True);t=time.time();r,idx=best(d,a.k);edges=';'.join(f'{int(d.iloc[e].i)}-{int(d.iloc[e].j)}' for e in idx)
    pd.DataFrame([[a.N,len(d),a.k,r,edges,time.time()-t]],columns=['N','M','k','best_residual','edges','runtime_s']).to_csv(a.out,index=False)
if __name__=='__main__':main()
