#!/usr/bin/env python3
from __future__ import annotations
import argparse,re
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib.pyplot as plt

def parse_edges(s):return str(s).replace(';',',').strip(',')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--raw-dir',type=Path,required=True);ap.add_argument('--output-dir',type=Path,default=Path('.'));a=ap.parse_args();out=a.output_dir;out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for N in (14,15,16):
        ex=pd.read_csv(a.raw_dir/f'exact_N{N}.csv')
        for _,r in ex.iterrows():rows.append([N,int(r.M),int(r.k),float(r.best_residual),parse_edges(r.edges),'EXACT exhaustive',True,float(r.best_residual)<1e-6])
        for k in (5,6):
            x=pd.read_csv(a.raw_dir/f'mitm_N{N}_k{k}.csv').iloc[0];rows.append([N,int(x.M),k,float(x.best_residual),parse_edges(x.edges),'MITM nearest-neighbor',False,float(x.best_residual)<1e-6])
        maxk={14:12,15:13,16:14}[N]
        for k in range(7,maxk+1):
            p=a.raw_dir/f'anneal_N{N}_k{k}.txt';line=p.read_text().strip().splitlines()[-1]
            parts=line.split('\t');r=float(parts[0]);edges=parse_edges(parts[1] if len(parts)>1 else '')
            rows.append([N,N*(N-1)//2,k,r,edges,'multistart simulated annealing + 1-swap descent',False,r<1e-6])
    df=pd.DataFrame(rows,columns=['N','M','k','best_residual_found','best_edges','method','globally_certified_for_this_k','below_1e-6']).sort_values(['N','k'])
    df.to_csv(out/'N14_N16_all_cardinalities_best_results.csv',index=False)
    sr=[]
    for N,g in df.groupby('N'):
        b=g.loc[g.best_residual_found.idxmin()]; below=g[g.below_1e-6]
        sr.append([N,int(b.M),int(g.k.min()),int(g.k.max()),float(b.best_residual_found),int(b.k),b.best_edges,','.join(map(str,below.k.astype(int))) if len(below) else '',len(below)])
    sm=pd.DataFrame(sr,columns=['N','M','k_min_searched','k_max_searched','best_residual_found','best_k','best_edges','k_below_1e-6','count_k_below_1e-6']);sm.to_csv(out/'N14_N16_summary.csv',index=False)
    fig,ax=plt.subplots(figsize=(9,5));
    for N,g in df.groupby('N'):ax.semilogy(g.k,g.best_residual_found,marker='o',label=f'N={N}')
    ax.axhline(1e-6,ls='--',lw=.8);ax.set_xlabel('subset cardinality k');ax.set_ylabel('best residual found');ax.legend();ax.set_title('N=14..16 best closure residual vs k');fig.tight_layout();fig.savefig(out/'N14_N16_best_residual_vs_k.png',dpi=180);plt.close(fig)
    piv=df.pivot(index='N',columns='k',values='best_residual_found');fig,ax=plt.subplots(figsize=(9,4));im=ax.imshow(np.log10(piv.to_numpy()),aspect='auto');ax.set_yticks(range(len(piv.index)),piv.index);ax.set_xticks(range(len(piv.columns)),piv.columns);ax.set_xlabel('k');ax.set_ylabel('N');ax.set_title('log10 best residual');fig.colorbar(im,ax=ax);fig.tight_layout();fig.savefig(out/'N14_N16_residual_heatmap.png',dpi=180);plt.close(fig)
if __name__=='__main__':main()
