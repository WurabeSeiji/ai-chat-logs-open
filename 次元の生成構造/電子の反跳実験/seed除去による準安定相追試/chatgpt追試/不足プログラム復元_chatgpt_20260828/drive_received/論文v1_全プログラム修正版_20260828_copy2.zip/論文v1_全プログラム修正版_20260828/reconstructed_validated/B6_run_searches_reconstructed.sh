#!/bin/sh
set -eu
if [ "$#" -ne 2 ]; then echo "usage: $0 SOURCE_DIR OUTPUT_DIR" >&2; exit 2; fi
SRC=$1
OUT=$2
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$OUT/raw"
CXX=${CXX:-c++}
"$CXX" -O3 -std=c++17 "$HERE/../recovered_original/exact_k234.cpp" -o "$OUT/exact_k234"
"$CXX" -O3 -std=c++17 "$HERE/../recovered_original/anneal_subsets.cpp" -o "$OUT/anneal_subsets"
for N in 14 15 16; do
  "$OUT/exact_k234" "$N" "$SRC/SOURCE_N${N}_step5000_final_edges.csv" "$OUT/raw/exact_N${N}.csv"
  for k in 5 6; do python3 "$HERE/B6_mitm_generic.py" "$N" "$k" "$SRC/SOURCE_N${N}_step5000_final_edges.csv" "$OUT/raw/mitm_N${N}_k${k}.csv"; done
done
# Historical steps/seeds were not preserved. This loop uses the explicitly documented reconstructed table.
tail -n +2 "$HERE/anneal_args_reconstructed.csv" | while IFS=, read -r N k steps seed status; do
  "$OUT/anneal_subsets" "$N" "$k" "$SRC/SOURCE_N${N}_step5000_final_edges.csv" "$steps" "$seed" > "$OUT/raw/anneal_N${N}_k${k}.txt"
done
python3 "$HERE/B6_aggregate_search_results.py" --raw-dir "$OUT/raw" --output-dir "$OUT"
