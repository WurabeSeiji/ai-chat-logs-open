#!/usr/bin/env python3
from __future__ import annotations
import argparse,itertools
from pathlib import Path
import numpy as np,pandas as pd
TOL=1e-6

def normres(v):return float(abs(v.sum())/np.abs(v).sum())
def hits(q,k):
    out=[]
    for c in itertools.combinations(range(len(q)),k):
        r=normres(q[list(c)])
        if r<TOL:out.append((r,c))
    out.sort(key=lambda x:x[0])
    return out

def exact_covers(M,subsets,limit=100):
    if not subsets or M%len(subsets[0][1]):return []
    by={i:[] for i in range(M)}
    for si,s in enumerate(subsets):
        for e in s[1]:by[e].append(si)
    sols=[]
    def rec(used,chosen):
        if len(sols)>=limit:return
        if len(used)==M:sols.append(chosen.copy());return
        e=min([x for x in range(M) if x not in used],key=lambda x:sum(1 for si in by[x] if not(set(subsets[si][1])&used)))
        for si in by[e]:
            b=set(subsets[si][1])
            if not b&used:rec(used|b,chosen+[si])
    rec(set(),[]);return sols

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source-dir',type=Path,required=True);ap.add_argument('--output',type=Path,default=Path('N3_N16_zero_subset_exact_covers.csv'));a=ap.parse_args()
    rows=[]
    for N in range(3,17):
        d=pd.read_csv(a.source_dir/f'SOURCE_N{N}_step5000_final_edges.csv').sort_values('edge_index').reset_index(drop=True);q=d.z2_re.to_numpy()+1j*d.z2_im.to_numpy();M=len(d)
        for k in (2,3):
            hs=hits(q,k);sols=exact_covers(M,hs)
            for ci,sol in enumerate(sols[:20]):
                rs=[hs[si][0] for si in sol];blocks=[]
                for si in sol:
                    blocks.append('+'.join(f'{int(d.iloc[e].i)}-{int(d.iloc[e].j)}' for e in hs[si][1]))
                rows.append([N,M,k,ci,len(sol),max(rs),float(np.mean(rs)),' | '.join(blocks)])
    pd.DataFrame(rows,columns=['N','M','subset_size','cover_id','block_count','max_block_residual','mean_block_residual','blocks']).to_csv(a.output,index=False)
if __name__=='__main__':main()
