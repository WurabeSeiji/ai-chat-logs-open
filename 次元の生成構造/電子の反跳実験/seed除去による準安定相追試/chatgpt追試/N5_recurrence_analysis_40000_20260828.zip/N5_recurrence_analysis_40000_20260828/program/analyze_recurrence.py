import numpy as np, pandas as pd, matplotlib.pyplot as plt, json, os, zipfile, hashlib
from pathlib import Path
src=Path('/mnt/data/N5_linear124_all3fix_seedless_parentnorm_removed_40000_20260828')
out=Path('/mnt/data/N5_recurrence_analysis_40000_20260828')
(out/'data').mkdir(parents=True, exist_ok=True)
(out/'figures').mkdir(parents=True, exist_ok=True)
(out/'program').mkdir(parents=True, exist_ok=True)
Z=np.load(src/'data/states_treatment.npz')['Z']
T,M=Z.shape
# reference recurrence to initial state, phase-optimized
z0=Z[0]
n0=np.linalg.norm(z0)
norms=np.linalg.norm(Z,axis=1)
inner=np.sum(np.conj(z0)[None,:]*Z,axis=1)
D0=np.sqrt(np.maximum(n0*n0+norms*norms-2*np.abs(inner),0))
F0=np.abs(inner)/(n0*norms)
# global lag autocorrelation via FFT, summed over components
nfft=1
while nfft<2*T: nfft*=2
C=np.zeros(T,dtype=np.complex128)
for m in range(M):
    x=Z[:,m]
    fx=np.fft.fft(x,nfft)
    ac=np.fft.ifft(np.conj(fx)*fx)[:T]
    C += ac
# energies over overlapping windows
E=np.sum(np.abs(Z)**2,axis=1)
cs=np.concatenate([[0.0],np.cumsum(E)])
# for lag tau: sum_{t=0}^{T-tau-1} E_t and E_{t+tau}
tau=np.arange(T)
E1=cs[T-tau]-cs[0]
E2=cs[T]-cs[tau]
Dg=np.sqrt(np.maximum(E1+E2-2*np.abs(C),0)/np.maximum(T-tau,1))
Fg=np.abs(C)/np.sqrt(np.maximum(E1*E2,1e-300))
# Save full data
pd.DataFrame({'tau':tau,'D_initial_phaseopt':D0,'fidelity_initial':F0,'D_global_rms_phaseopt':Dg,'fidelity_global':Fg}).to_csv(out/'data/recurrence_spectrum.csv',index=False)
# candidate minima excluding tau 0; local minima
arr=D0
idx=np.arange(1,T-1)
loc=idx[(arr[1:-1] <= arr[:-2]) & (arr[1:-1] <= arr[2:])]
loc=loc[np.argsort(arr[loc])]
# nontrivial separated candidates top 50
cand0=loc[:200]
# global minima
arrg=Dg
locg=idx[(arrg[1:-1] <= arrg[:-2]) & (arrg[1:-1] <= arrg[2:])]
locg=locg[np.argsort(arrg[locg])]
# save top candidates
rows=[]
for rank,i in enumerate(cand0[:50],1): rows.append(('initial',rank,int(i),float(D0[i]),float(F0[i])))
for rank,i in enumerate(locg[:50],1): rows.append(('global',rank,int(i),float(Dg[i]),float(Fg[i])))
pd.DataFrame(rows,columns=['metric','rank','tau','distance','fidelity']).to_csv(out/'data/top_recurrence_candidates.csv',index=False)
# Plot initial distance log y
plt.figure(figsize=(11,6))
plt.plot(tau[1:],D0[1:],lw=0.8)
plt.yscale('log')
plt.xlabel('lag tau (steps)')
plt.ylabel('phase-optimized distance to Z(0)')
plt.title('N=5 recurrence spectrum vs initial state (40000 steps)')
plt.grid(True,which='both',alpha=.25)
plt.tight_layout(); plt.savefig(out/'figures/recurrence_initial_log.png',dpi=180); plt.close()
# fidelity initial
plt.figure(figsize=(11,6))
plt.plot(tau[1:],F0[1:],lw=0.8)
plt.xlabel('lag tau (steps)'); plt.ylabel('|<Z(0),Z(tau)>|/(||Z0|| ||Ztau||)')
plt.title('N=5 phase-invariant fidelity to initial state')
plt.grid(True,alpha=.25); plt.tight_layout(); plt.savefig(out/'figures/fidelity_initial.png',dpi=180); plt.close()
# global
plt.figure(figsize=(11,6))
plt.plot(tau[1:],Dg[1:],lw=0.8)
plt.yscale('log')
plt.xlabel('lag tau (steps)'); plt.ylabel('global RMS phase-optimized distance')
plt.title('N=5 lag-averaged recurrence spectrum')
plt.grid(True,which='both',alpha=.25); plt.tight_layout(); plt.savefig(out/'figures/recurrence_global_log.png',dpi=180); plt.close()
# zoom top maybe tau 0..5000
plt.figure(figsize=(11,6))
mx=min(5000,T-1)
plt.plot(tau[1:mx+1],D0[1:mx+1],lw=0.8)
plt.yscale('log'); plt.xlabel('lag tau'); plt.ylabel('distance to Z(0)')
plt.title('N=5 recurrence spectrum zoom: tau <= 5000')
plt.grid(True,which='both',alpha=.25); plt.tight_layout(); plt.savefig(out/'figures/recurrence_initial_zoom5000.png',dpi=180); plt.close()
# detect exact-ish or strong recurrences thresholds
summary={
 'T':int(T),'M':int(M),'norm0':float(n0),'norm_min':float(norms.min()),'norm_max':float(norms.max()),
 'best_initial_tau':int(cand0[0]) if len(cand0) else None,
 'best_initial_distance':float(D0[cand0[0]]) if len(cand0) else None,
 'best_initial_fidelity':float(F0[cand0[0]]) if len(cand0) else None,
 'best_global_tau':int(locg[0]) if len(locg) else None,
 'best_global_distance':float(Dg[locg[0]]) if len(locg) else None,
 'best_global_fidelity':float(Fg[locg[0]]) if len(locg) else None,
 'initial_taus_D_lt_1e-6':[int(i) for i in np.where(D0[1:]<1e-6)[0][:50]+1],
 'initial_taus_D_lt_1e-3':[int(i) for i in np.where(D0[1:]<1e-3)[0][:50]+1],
}
(out/'data/summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
# report
lines=['# N=5 40000-step recurrence analysis','',f'T={T}, M={M}. Global phase is quotiented out.','',
       '## Best recurrences to initial state']
for i in cand0[:15]: lines.append(f'- tau={int(i)}: D={D0[i]:.12e}, fidelity={F0[i]:.12f}')
lines+=['','## Best lag-averaged recurrences']
for i in locg[:15]: lines.append(f'- tau={int(i)}: D_rms={Dg[i]:.12e}, fidelity={Fg[i]:.12f}')
lines+=['','## Interpretation',
'An exact U^n=I recurrence would require the full complex state to return (up to the explicitly quotiented global phase) at a sharply defined lag with distance near numerical precision, and preferably repeat at integer multiples. The tables/plots above test that directly rather than inferring periodicity from H_perp alone.']
(out/'analysis_report_ja.md').write_text('\n'.join(lines),encoding='utf-8')
(out/'README.md').write_text('40000-step treatment state recurrence analysis.\n',encoding='utf-8')
# copy script
import shutil; shutil.copy(__file__,out/'program/analyze_recurrence.py')
# sha
hashes=[]
for p in sorted(out.rglob('*')):
    if p.is_file(): hashes.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(out)}")
(out/'SHA256SUMS.txt').write_text('\n'.join(hashes)+'\n')
zip_path=Path('/mnt/data/N5_recurrence_analysis_40000_20260828.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in out.rglob('*'):
        if p.is_file(): z.write(p,p.relative_to(out.parent))
print(json.dumps(summary,indent=2))
print('zip',zip_path)
