# N=5 40000-step recurrence analysis

T=40001, M=10. Global phase is quotiented out.

## Best recurrences to initial state
- tau=638: D=2.769649084217e-02, fidelity=0.999553832148
- tau=1261: D=5.321942643922e-02, fidelity=0.998352637561
- tau=1871: D=7.690896706818e-02, fidelity=0.996559649130
- tau=2470: D=9.900351094998e-02, fidelity=0.994299014028
- tau=3059: D=1.197002882989e-01, fidelity=0.991666274856
- tau=3639: D=1.391315750922e-01, fidelity=0.988740990554
- tau=4211: D=1.574340586465e-01, fidelity=0.985583953869
- tau=4777: D=1.746987356901e-01, fidelity=0.982248776017
- tau=5337: D=1.910247246688e-01, fidelity=0.978775965410
- tau=5891: D=2.064871568737e-01, fidelity=0.975200960006
- tau=6441: D=2.211445317731e-01, fidelity=0.971555310978
- tau=6986: D=2.350626009603e-01, fidelity=0.967862221397
- tau=7527: D=2.482977667670e-01, fidelity=0.964141311062
- tau=8065: D=2.609409776122e-01, fidelity=0.960396519934
- tau=8600: D=2.731309278844e-01, fidelity=0.956609911074

## Best lag-averaged recurrences
- tau=464: D_rms=3.633723228962e-01, fidelity=0.923201547269
- tau=1443: D_rms=7.685946037870e-01, fidelity=0.656407684660
- tau=2011: D_rms=8.707747555855e-01, fidelity=0.558977811501
- tau=5113: D_rms=9.099322165186e-01, fidelity=0.518421750985
- tau=4619: D_rms=9.117484584489e-01, fidelity=0.516497353729
- tau=5625: D_rms=9.167216767947e-01, fidelity=0.511208346284
- tau=6133: D_rms=9.251729198139e-01, fidelity=0.502154478585
- tau=4118: D_rms=9.293921173698e-01, fidelity=0.497603333202
- tau=2540: D_rms=9.300214301041e-01, fidelity=0.496922734227
- tau=6635: D_rms=9.386212717858e-01, fidelity=0.487575879231
- tau=3602: D_rms=9.519572685408e-01, fidelity=0.472911320978
- tau=3067: D_rms=9.589247983526e-01, fidelity=0.465167389521
- tau=7116: D_rms=9.622973098396e-01, fidelity=0.461398791696
- tau=7596: D_rms=9.915116762059e-01, fidelity=0.428199611929
- tau=8160: D_rms=1.013431169069e+00, fidelity=0.402638409561

## Interpretation
An exact U^n=I recurrence would require the full complex state to return (up to the explicitly quotiented global phase) at a sharply defined lag with distance near numerical precision, and preferably repeat at integer multiples. The tables/plots above test that directly rather than inferring periodicity from H_perp alone.