40000-step treatment state recurrence analysis.
